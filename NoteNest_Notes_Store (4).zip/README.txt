# NoteNest Notes Store

Open `index.html` in a browser to preview the website.

## To customize
1. Replace the store name and text in `index.html`.
2. Replace YOUR_PAYMENT_LINK_1 etc. with your actual payment/checkout links.
3. Replace YOUR_EMAIL@example.com with your contact email.
4. Change prices and note names.
5. Upload the folder to a static hosting service.

Important: because you are under 18, have a parent/guardian help with payment accounts, payouts, taxes/legal requirements, and any platform account that requires an adult.
